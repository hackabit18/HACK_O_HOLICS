 var express=require("express");
 var app=express();
 var bodyParser=require("body-parser");
 var mongoose =require("mongoose");
 
 
 mongoose.connect("mongodb://localhost/competitions");
 mongoose.connect("mongodb://localhost/achievements");
 
 
 app.use(bodyParser.urlencoded({extended: true}));
 app.set("view engine" ,"ejs");
 app.use(express.static("public"));
 var competitionSchema = new mongoose.Schema({
      competitionName:String,
      words:String,
      url:String.
   });
 
 var Competition = mongoose.model("competition", competitionSchema);
 
 app.get("/", function(req, res){
    res.render("home");
 });
 
 
 app.get("/competitions", function(req, res){
     Competition.find({}, function(err, allcompetitions){
        if(err){
         console.log(err);
        }else{
         res.render("competitions");
        }
     });
 });
 
 
 app.post("/competitions", function(req, res){
     var competitionName=req.body.competitionname;
     var words=req.body.words;
     
     var url=req.body.url;
     
     var newCompetition={competitionName:competitionName, words:words, url:url};
     Competition.create(newCompetition, function(err, newlycreated){
       if(err){
        console.log(err);
       }else{
        res.redirect("/competitions");
       }
     });
 });
 
 
 
 
 var achievementSchema = new mongoose.Schema({
      erpid:String,
      achievementsName:String,
      date:String,
      url:String,
      organisation:String.
   });
 
 var Achievement = mongoose.model("achievement", achievementSchema);
 
 
 
 app.get("/achievements", function(req, res){
     Achievements.find({}, function(err, allachievements){
        if(err){
         console.log(err);
        }else{
         res.render("achievements");
        }
     });
 });
 
 
 app.post("/achievements", function(req, res){
     var erpid=req.body.ERPID;
     var achievementsName=req.body.achievementsName;
     var date=req.body.date;
     var organisation=req.body.organisation;
     var url=req.body.url;
     
     var newAchievements={erpid: ERPID, achievementsName:achievementsName, date:date, organisation:organisation, url:url};
     Achievement.create(newAchievements, function(err, newlycreated){
       if(err){
        console.log(err);
       }else{
        res.redirect("/achievements");
       }
     });
 });
 
 var projectscseSchema = new mongoose.Schema({
      erpid:String,
      projectscseName:String,
      date:String,
      url:String,
     
   });
 
var Achievement = mongoose.model("achievement", achievementSchema);
  app.get("/projectscse", function(req, res){
     Projectscse.find({}, function(err, allprojectscse){
        if(err){
         console.log(err);
        }else{
         res.render("projectscse");
        }
     });
 });
 
 
 app.get("/projectscse", function(req, res){
     res.render("projectscse");
 });
 
 app.get("/projectscse", function(req, res){
     res.render("projectsece");
 });
 
 app.get("/projectscse", function(req, res){
     res.render("projectsmech");
 });
 
 app.get("/projectscse", function(req, res){
     res.render("projectscivil");
 });
 
 app.get("/query", function(req, res){
     res.render("query"); 
     
     
 });
 
 app.listen(process.env.PORT, process.env.IP, function(){
     console.log("Server has started!");
 });